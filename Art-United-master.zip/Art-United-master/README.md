# Art-United
This Project is build using HTML,CSS and Javascript for frontend and Node.js and it's frame works for backend.MongoDb is used as the Database. 

## There are 5 main pages:
* landing page: This page is the home page.
* Login page: This is the Login page.
* Sign Up page: This is the register/signup page.
* Index page: This is the page to show all the artworks in the database.
* Show page: This page shows details of a particular artwork from here you can add comment, edit artwork and delete a particular artwork.

**Authorization** is taken into account while giving rights to a user to edit or delete a artwork.Only the user who had made a particular artwork can delete or edit that artwork. 

**Authentication** is also taken into account while adding comments( a user can only add comments if he/she is logged in).
